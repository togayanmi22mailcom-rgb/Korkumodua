package com.korkumodu;

import net.fabricmc.api.ModInitializer;
import net.fabricmc.fabric.api.networking.v1.ServerPlayConnectionEvents;
import net.minecraft.network.chat.Component;

public class KorkuModu implements ModInitializer {
    public static final String MOD_ID = "korkumodu";

    @Override
    public void onInitialize() {
        // Oyunu oynayan kişi dünyaya girince çalışır
        ServerPlayConnectionEvents.JOIN.register((handler, sender, server) -> {
            
            // Oyunu o an kim oynuyorsa onun MC adını çeker
            String oyunuOynayanKisininMCAdi = handler.getPlayer().getName().getString();

            // Oyuncunun ekranına kırmızı yazıyla mesajı gönderir
            handler.getPlayer().sendSystemMessage(
                Component.nullToEmpty("§cAdın: " + oyunuOynayanKisininMCAdi + " mi? Seni izliyorum...")
            );
        });
    }
}
