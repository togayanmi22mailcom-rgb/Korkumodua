BLUE AND RED DOOR — Minecraft Java 1.20.1 / Forge 47.3.0

Bu paket kaynak kodlarını ve GitHub Actions ile çevrimiçi derleme yapılandırmasını içerir. Henüz derlenmiş JAR içermez.

ÖZELLİKLER
- Mavi Kapı ve Kırmızı Kapı özel envanter eşyalarıdır.
- Hayatta kalma modunda her oyuncuya rastgele 3–5 dakikada bir kapı verilir.
- Uyarı action bar ve sohbet üzerinden gösterilir.
- Kapı sağ tıklanınca oyuncu aynı boyutta oluşturulan güvenli veya tehlikeli odaya ışınlanır.
- Güvenli odada yiyecek ve hayatta kalma eşyaları içeren iki sandık bulunur.
- Tehlikeli odada ağlar ve düşük canlı “Kapı Avcısı” adlı zombi bulunur.

TELEFONDAN ÇEVRİMİÇİ DERLEME (BİLGİSAYAR VE GRADLE KURMADAN)
1. ZIP'i indir ve telefonunda çıkar.
2. GitHub'da yeni, tercihen Private bir repository oluştur.
3. ZIP içindeki BlueAndRedDoor klasörünün İÇİNDEKİ dosyaları repository'nin köküne yükle. .github klasörünün de yüklendiğinden emin ol. GitHub web arayüzünde Add file > Upload files kullanılabilir. Klasör yükleme desteklenmezse dosyaları alt klasörleriyle tek tek oluşturup yüklemek gerekir; GitHub Desktop gerekmez.
4. Yükleme tamamlanınca Actions sekmesini aç. “Build Blue and Red Door” iş akışını seç. Gerekirse “Run workflow” düğmesine bas.
5. İş akışı tamamlanana kadar bekle. Yeşil onay başarılı derlemeyi gösterir. Kırmızı çarpı derleme hatasıdır; logları kontrol etmek gerekir.
6. Başarılı çalıştırmanın sayfasının altındaki Artifacts bölümünden “BlueAndRedDoor-Forge-1.20.1” dosyasını indir. Bu artifact ZIP'inin içinde .jar dosyası olur.
7. İçindeki JAR'ı Minecraft Java 1.20.1 + Forge 47.x kurulumunun mods klasörüne koy. Oyunu başlatmadan önce dünyanı yedekle.

GEREKSİNİMLER
- Minecraft Java Edition 1.20.1
- Forge 1.20.1, önerilen 47.3.0
- Çevrimiçi derleme için GitHub hesabı ve internet
- GitHub Actions'ın repository için etkin olması

SINIRLAR VE DÜRÜST NOT
Bu çalışma ortamında Forge bağımlılıkları indirilip gerçek derleme/oyun testi yapılamadı. Bu yüzden bu paket derlenmiş JAR değildir ve kaynak kodunun hatasız derlendiği henüz doğrulanmadı. GitHub Actions build başarısız olursa logdaki hata çözülmelidir. Tehlikeli odadaki düşman ayrı bir özel Entity sınıfı değil, canı azaltılmış ve adı değiştirilmiş bir zombidir. Kapıların rengi sonucu belirlemez; her ikisi de iki oda türünden rastgele birine götürür.
