package com.boralo.blueandreddoor;

import net.minecraft.ChatFormatting;
import net.minecraft.network.chat.Component;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.world.item.ItemStack;
import net.minecraftforge.event.TickEvent;
import net.minecraftforge.event.entity.player.PlayerEvent;
import net.minecraftforge.eventbus.api.SubscribeEvent;

import java.util.HashMap;
import java.util.Map;
import java.util.Random;
import java.util.UUID;

/** Server-side timer: each player receives a random door every 3–5 minutes. */
public class DoorEventHandlers {
    private static final Random RANDOM = new Random();
    private static final Map<UUID, Integer> TICKS_UNTIL_DROP = new HashMap<>();

    private static int nextDelay() {
        return (180 + RANDOM.nextInt(121)) * 20; // 180–300 seconds, 20 ticks/sec
    }

    @SubscribeEvent
    public void onPlayerTick(TickEvent.PlayerTickEvent event) {
        if (event.phase != TickEvent.Phase.END || event.player.level().isClientSide || !(event.player instanceof ServerPlayer player)) return;
        if (!player.isAlive() || player.isSpectator()) return;
        UUID id = player.getUUID();
        int remaining = TICKS_UNTIL_DROP.computeIfAbsent(id, ignored -> nextDelay());
        remaining--;
        if (remaining <= 0) {
            boolean blue = RANDOM.nextBoolean();
            ItemStack door = new ItemStack(blue ? BlueAndRedDoorMod.BLUE_DOOR.get() : BlueAndRedDoorMod.RED_DOOR.get());
            if (!player.getInventory().add(door)) player.drop(door, false);
            player.displayClientMessage(Component.literal("Süre başladı! Kırmızı veya Mavi kapıyı seç ve sağ tıkla!")
                    .withStyle(ChatFormatting.AQUA, ChatFormatting.BOLD), true);
            player.displayClientMessage(Component.literal(blue ? "Envanterine Mavi Kapı eklendi!" : "Envanterine Kırmızı Kapı eklendi!")
                    .withStyle(blue ? ChatFormatting.BLUE : ChatFormatting.RED), false);
            remaining = nextDelay();
        }
        TICKS_UNTIL_DROP.put(id, remaining);
    }

    @SubscribeEvent
    public void onLogout(PlayerEvent.PlayerLoggedOutEvent event) {
        TICKS_UNTIL_DROP.remove(event.getEntity().getUUID());
    }
}
