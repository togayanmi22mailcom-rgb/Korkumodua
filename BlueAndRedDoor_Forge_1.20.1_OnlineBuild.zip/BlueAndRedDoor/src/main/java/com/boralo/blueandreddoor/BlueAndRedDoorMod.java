package com.boralo.blueandreddoor;

import net.minecraft.world.item.Item;
import net.minecraftforge.eventbus.api.IEventBus;
import net.minecraftforge.fml.common.Mod;
import net.minecraftforge.fml.javafmlmod.FMLJavaModLoadingContext;
import net.minecraftforge.registries.DeferredRegister;
import net.minecraftforge.registries.ForgeRegistries;
import net.minecraftforge.registries.RegistryObject;

@Mod(BlueAndRedDoorMod.MOD_ID)
public class BlueAndRedDoorMod {
    public static final String MOD_ID = "blueandreddoor";
    private static final DeferredRegister<Item> ITEMS = DeferredRegister.create(ForgeRegistries.ITEMS, MOD_ID);

    public static final RegistryObject<Item> BLUE_DOOR = ITEMS.register("blue_door",
            () -> new DoorItem(new Item.Properties(), true));
    public static final RegistryObject<Item> RED_DOOR = ITEMS.register("red_door",
            () -> new DoorItem(new Item.Properties(), false));

    public BlueAndRedDoorMod() {
        IEventBus modBus = FMLJavaModLoadingContext.get().getModEventBus();
        ITEMS.register(modBus);
        net.minecraftforge.common.MinecraftForge.EVENT_BUS.register(new DoorEventHandlers());
    }
}
