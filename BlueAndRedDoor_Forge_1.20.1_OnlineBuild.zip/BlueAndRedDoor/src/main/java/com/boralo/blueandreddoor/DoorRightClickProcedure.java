package com.boralo.blueandreddoor;

import net.minecraft.core.BlockPos;
import net.minecraft.core.registries.Registries;
import net.minecraft.network.chat.Component;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.world.entity.EntityType;
import net.minecraft.world.entity.MobSpawnType;
import net.minecraft.world.entity.monster.Zombie;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.Items;
import net.minecraft.world.level.Level;
import net.minecraft.world.level.block.Blocks;
import net.minecraft.world.level.block.ChestBlock;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.level.block.entity.ChestBlockEntity;
import net.minecraft.world.level.block.entity.BlockEntity;
import net.minecraft.world.level.block.Rotation;
import net.minecraft.world.level.block.Mirror;
import net.minecraft.world.level.material.Fluids;
import net.minecraft.ChatFormatting;

import java.util.Random;

/** Creates a small room in a remote, prepared area and teleports the player there. */
public final class DoorRightClickProcedure {
    private static final Random RANDOM = new Random();
    private static final int ROOM_SPACING = 48;
    private DoorRightClickProcedure() {}

    public static void useDoor(ServerPlayer player, boolean blueDoor) {
        ServerLevel level = player.serverLevel();
        // The colour is flavour only: either door can lead to either room.
        boolean safeRoom = RANDOM.nextBoolean();
        int slot = RANDOM.nextInt(10000);
        int x = 10000 + (slot % 100) * ROOM_SPACING;
        int z = 10000 + (slot / 100) * ROOM_SPACING;
        int y = Math.max(level.getMinBuildHeight() + 8, Math.min(90, level.getMaxBuildHeight() - 12));
        BlockPos origin = new BlockPos(x, y, z);
        buildRoom(level, origin, safeRoom);
        player.teleportTo(level, x + 2.5, y + 1.0, z + 2.5, player.getYRot(), player.getXRot());
        player.fallDistance = 0;
        player.displayClientMessage(Component.literal(safeRoom ? "GÜVENLİ ODA — biraz dinlen!" : "TEHLİKELİ ODA — Kapı Avcısı burada!")
                .withStyle(safeRoom ? ChatFormatting.GREEN : ChatFormatting.DARK_RED, ChatFormatting.BOLD), false);
    }

    private static void buildRoom(ServerLevel level, BlockPos o, boolean safe) {
        // Clear a 7x5x7 volume so the destination is usable.
        for (int x = -1; x <= 7; x++) for (int z = -1; z <= 7; z++) for (int y = 0; y <= 5; y++) {
            BlockPos p = o.offset(x, y, z);
            if (level.isInWorldBounds(p)) level.setBlock(p, Blocks.AIR.defaultBlockState(), 3);
        }
        BlockState wall = safe ? Blocks.SMOOTH_STONE.defaultBlockState() : Blocks.DEEPSLATE_BRICKS.defaultBlockState();
        BlockState floor = safe ? Blocks.OAK_PLANKS.defaultBlockState() : Blocks.POLISHED_BLACKSTONE.defaultBlockState();
        for (int x = 0; x <= 6; x++) for (int z = 0; z <= 6; z++) {
            level.setBlock(o.offset(x, 0, z), floor, 3);
            level.setBlock(o.offset(x, 4, z), wall, 3);
            if (x == 0 || x == 6 || z == 0 || z == 6) {
                for (int y = 1; y <= 3; y++) level.setBlock(o.offset(x, y, z), wall, 3);
            }
        }
        // Doorway, lights, and a clear player landing spot.
        for (int y = 1; y <= 2; y++) level.setBlock(o.offset(3, y, 0), Blocks.AIR.defaultBlockState(), 3);
        level.setBlock(o.offset(1, 3, 1), safe ? Blocks.LANTERN.defaultBlockState() : Blocks.SOUL_LANTERN.defaultBlockState(), 3);
        level.setBlock(o.offset(5, 3, 5), safe ? Blocks.LANTERN.defaultBlockState() : Blocks.SOUL_LANTERN.defaultBlockState(), 3);
        if (safe) {
            placeChest(level, o.offset(2, 1, 3), Items.BREAD, Items.COOKED_BEEF, Items.IRON_PICKAXE, Items.TORCH, Items.COOKED_BEEF);
            placeChest(level, o.offset(4, 1, 3), Items.OAK_PLANKS, Items.IRON_INGOT, Items.SHIELD, Items.BREAD);
        } else {
            level.setBlock(o.offset(2, 1, 2), Blocks.COBWEB.defaultBlockState(), 3);
            level.setBlock(o.offset(4, 1, 4), Blocks.COBWEB.defaultBlockState(), 3);
            Zombie mob = EntityType.ZOMBIE.create(level);
            if (mob != null) {
                mob.moveTo(o.getX() + 4.5, o.getY() + 1, o.getZ() + 3.5, RANDOM.nextFloat() * 360F, 0);
                mob.setCustomName(Component.literal("Kapı Avcısı").withStyle(ChatFormatting.DARK_RED));
                mob.setCustomNameVisible(true);
                mob.setHealth(8.0F); // Its low health is its weakness.
                mob.setPersistenceRequired();
                level.addFreshEntity(mob);
            }
            level.setBlock(o.offset(3, 1, 5), Blocks.CHEST.defaultBlockState(), 3);
        }
    }

    private static void placeChest(ServerLevel level, BlockPos pos, net.minecraft.world.item.Item... loot) {
        level.setBlock(pos, Blocks.CHEST.defaultBlockState(), 3);
        BlockEntity be = level.getBlockEntity(pos);
        if (be instanceof ChestBlockEntity chest) {
            for (int i = 0; i < loot.length; i++) chest.setItem(i, new ItemStack(loot[i], 1 + RANDOM.nextInt(3)));
            chest.setChanged();
        }
    }
}
